creds = {
	"input_login" : "//input[@id='email' or @name='email']",
	"input_password" : "//input[@id='pass']",
	"button_login" : "//button[@id='loginbutton']"
}

Birthday_xpath_creds = "inlineReplyTextArea"