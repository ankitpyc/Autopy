import sys
from python_cronjob_setter import set_schedule
def schedulers():
	print "setting schedule"
	set_schedule()
schedulers()	