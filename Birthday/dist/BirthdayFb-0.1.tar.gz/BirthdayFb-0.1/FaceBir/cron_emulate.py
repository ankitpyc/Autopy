#!/usr/bin/python
import subprocess
import os
subprocess.call("python /home/geekowl/Desktop/ML_REPO/Autopys/Facebook_BirthdayWish_/Fb_Birthday/Happy_Birthday.py",shell=True)